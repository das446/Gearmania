# Gearmania

A game by David Saks, Lange Eo, Jiaji Li, Ethan Graham, Adam Tropf, and Joe Konieczny

## Controls

If you're using a keyboard use the left and right arrow keys to move, and the up arrow to jump.
Pressing x will throw the gear. Pressing z will drop the gear in place if you're holding it. If it's already dropped it will make it come to you instead.

## Gameplay

As of now when your gear hits an enemy or it's projectile the gear will destroy it, but it will also take some damage. 
If the gear takes too much damage it will be destroyed, but respawn a few seconds later.