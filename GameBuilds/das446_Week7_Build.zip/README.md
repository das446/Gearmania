# Gearmania

A game by David Saks, Lange Eo, Jiaji Li, Ethan Graham, Adam Tropf, and Joe Konieczny

## Controls

If you're using a keyboard use the left and right arrow keys to move, and the up arrow to jump. Or you can use wasd controls.
You can aim the gear with the mouse, left clicking will throw it in the direction and right clicking will drop it or retrieve it. The game does support wireless bluetooth controllers, although you may need to adjust the keymapping in the startup screen under input.

## Gameplay

As of now when your gear hits an enemy or it's projectile the gear will destroy it, but it will also take some damage. 
If the gear takes too much damage it will be destroyed, but respawn a few seconds later. The gear does heal slowly over time